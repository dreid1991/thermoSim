speciesDefs = 	{spc1: {m:3, r:2, cols: Col(200,0,0)},
				spc2: {m:5, r:6, cols: Col(0,200,200)},
				spc3: {m:1, r:1, cols: Col(225, 0, 225)}};
